---
name: Feature request
about: Suggest an idea for this project.
title: ''
labels: ''
assignees: ''
---

<!--

    Please do *NOT* ask support questions in Github issues.

    If your issue is not a feature request or bug report use our
    community support.

    https://prometheus.io/community/

    There is also commercial support available.

    https://prometheus.io/support-training/

-->
## Proposal
**Use case. Why is this important?**

*“Nice to have” is not a good use case. :)*
